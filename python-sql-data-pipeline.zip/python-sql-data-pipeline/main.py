#!/usr/bin/env python3
"""
Entry point for the Python SQL Data Pipeline.

Usage:
    python main.py
"""

import logging
import sys
from pathlib import Path

import yaml

from src.pipeline import run_pipeline


def setup_logging() -> None:
    """Configure root logger with a clean, readable format."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-5s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def load_config(path: str = "config.yaml") -> dict:
    """Load pipeline configuration from YAML."""
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def main() -> None:
    setup_logging()
    logger = logging.getLogger(__name__)

    try:
        config = load_config()
        report_path = run_pipeline(config)
        logger.info("Done. Report available at: %s", report_path)
    except Exception as exc:
        logger.exception("Pipeline failed: %s", exc)
        sys.exit(1)


if __name__ == "__main__":
    main()
