"""Unit tests for the data pipeline components."""

import sqlite3
from pathlib import Path

import pandas as pd
import pytest

from src.extractor import create_sample_database, extract
from src.transformer import run_data_quality_checks, transform
from src.loader import load_to_sqlite


@pytest.fixture
def sample_db(tmp_path):
    """Create a temporary sample database for testing."""
    db_path = str(tmp_path / "test.db")
    create_sample_database(db_path)
    return db_path


def test_create_sample_database(sample_db):
    assert Path(sample_db).exists()
    conn = sqlite3.connect(sample_db)
    count = conn.execute("SELECT COUNT(*) FROM sales").fetchone()[0]
    conn.close()
    assert count > 0


def test_extract(sample_db):
    df = extract(sample_db, "sales")
    assert isinstance(df, pd.DataFrame)
    assert len(df) > 0
    assert "amount" in df.columns
    assert "product" in df.columns


def test_data_quality_clean(sample_db):
    df = extract(sample_db, "sales")
    issues = run_data_quality_checks(df, "amount")
    # Sample data is clean – expect no issues
    assert issues == []


def test_transform(sample_db):
    df = extract(sample_db, "sales")
    summary = transform(df, "sale_date", "amount", "product")
    assert "year_month" in summary.columns
    assert "total_revenue" in summary.columns
    assert "total_quantity" in summary.columns
    assert len(summary) > 0
    # Revenue should be positive
    assert (summary["total_revenue"] > 0).all()


def test_load_to_sqlite(sample_db):
    df = extract(sample_db, "sales")
    summary = transform(df, "sale_date", "amount", "product")
    load_to_sqlite(summary, sample_db, table_name="test_summary")

    conn = sqlite3.connect(sample_db)
    loaded = pd.read_sql_query("SELECT * FROM test_summary", conn)
    conn.close()

    assert len(loaded) == len(summary)
