"""Orchestrate the full Extract → Transform → Load → Report pipeline."""

import logging
from typing import Any, Dict

from src.extractor import create_sample_database, extract
from src.transformer import run_data_quality_checks, transform
from src.loader import load_to_sqlite
from src.reporter import generate_report

logger = logging.getLogger(__name__)


def run_pipeline(config: Dict[str, Any]) -> str:
    """
    Execute the complete data pipeline using the provided configuration.

    Returns the path to the generated report file.
    """
    logger.info("Starting data pipeline...")

    db_cfg = config["database"]
    pipe_cfg = config["pipeline"]
    report_cfg = config["report"]

    # 1. Ensure sample data exists (for demo purposes)
    create_sample_database(db_cfg["path"])

    # 2. Extract
    raw_df = extract(db_cfg["path"], db_cfg["table"])

    # 3. Data quality checks
    issues = run_data_quality_checks(raw_df, pipe_cfg["amount_column"])
    if any("critical" in i.lower() for i in issues):
        logger.error("Critical data quality issues found – aborting pipeline")
        raise ValueError("Critical data quality issues detected")

    # 4. Transform
    summary_df = transform(
        raw_df,
        date_col=pipe_cfg["date_column"],
        amount_col=pipe_cfg["amount_column"],
        product_col=pipe_cfg["product_column"],
    )

    # 5. Load summary back into the database
    load_to_sqlite(summary_df, db_cfg["path"], table_name="sales_summary")

    # 6. Generate report
    report_path = generate_report(
        summary_df,
        output_dir=report_cfg["output_dir"],
        filename_prefix=report_cfg["filename_prefix"],
    )

    logger.info("Pipeline completed successfully")
    return report_path
