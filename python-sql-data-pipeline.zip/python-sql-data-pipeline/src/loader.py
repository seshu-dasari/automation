"""Load transformed data back into the database or export targets."""

import logging
import sqlite3
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def load_to_sqlite(df: pd.DataFrame, db_path: str, table_name: str = "sales_summary") -> None:
    """
    Load the transformed DataFrame into a summary table in SQLite.
    Replaces the table if it already exists.
    """
    logger.info("Loading %d rows into table '%s'", len(df), table_name)

    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    try:
        df.to_sql(table_name, conn, if_exists="replace", index=False)
        conn.commit()
    finally:
        conn.close()

    logger.info("Successfully loaded data into '%s'", table_name)
