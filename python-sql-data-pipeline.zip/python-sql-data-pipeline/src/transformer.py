"""Transform and validate extracted data."""

import logging
from typing import Dict, List, Tuple

import pandas as pd

logger = logging.getLogger(__name__)


def run_data_quality_checks(df: pd.DataFrame, amount_col: str) -> List[str]:
    """
    Run basic data-quality checks and return a list of issues found.

    Checks:
    - Null values in critical columns
    - Duplicate rows
    - Negative or zero amounts
    """
    issues: List[str] = []

    # Null checks
    null_counts = df.isnull().sum()
    for col, count in null_counts.items():
        if count > 0:
            issues.append(f"Column '{col}' has {count} null value(s)")

    # Duplicate check
    dup_count = df.duplicated().sum()
    if dup_count > 0:
        issues.append(f"Found {dup_count} duplicate row(s)")

    # Amount validation
    if amount_col in df.columns:
        negative = (df[amount_col] <= 0).sum()
        if negative > 0:
            issues.append(f"Found {negative} row(s) with non-positive amount")

    if issues:
        logger.warning("Data quality issues detected: %s", issues)
    else:
        logger.info("Data quality: 0 critical issues found")

    return issues


def transform(df: pd.DataFrame, date_col: str, amount_col: str, product_col: str) -> pd.DataFrame:
    """
    Transform raw sales data into a monthly product summary.

    - Parse dates
    - Aggregate total revenue and quantity by month + product
    - Sort results
    """
    logger.info("Starting transformation on %d rows", len(df))

    working = df.copy()

    # Ensure date column is datetime
    working[date_col] = pd.to_datetime(working[date_col])
    working["year_month"] = working[date_col].dt.to_period("M").astype(str)

    summary = (
        working.groupby(["year_month", product_col], as_index=False)
        .agg(
            total_revenue=(amount_col, "sum"),
            total_quantity=("quantity", "sum"),
            order_count=(amount_col, "count"),
        )
        .sort_values(["year_month", "total_revenue"], ascending=[True, False])
    )

    # Round money values
    summary["total_revenue"] = summary["total_revenue"].round(2)

    logger.info("Transformed data → %d monthly summary rows", len(summary))
    return summary
