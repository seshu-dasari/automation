"""Generate human-readable and machine-readable reports."""

import logging
from datetime import date
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)


def generate_report(df: pd.DataFrame, output_dir: str, filename_prefix: str) -> str:
    """
    Write a CSV report and print a short console summary.

    Returns the path to the generated CSV file.
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    today = date.today().isoformat()
    filename = f"{filename_prefix}_{today}.csv"
    filepath = Path(output_dir) / filename

    df.to_csv(filepath, index=False)
    logger.info("Report written to %s", filepath)

    # Console summary
    print("\n" + "=" * 60)
    print("SALES SUMMARY REPORT")
    print("=" * 60)
    print(f"Report date : {today}")
    print(f"Total rows  : {len(df)}")
    if not df.empty and "total_revenue" in df.columns:
        print(f"Total revenue (all months): ${df['total_revenue'].sum():,.2f}")
        print("\nTop 5 rows by revenue:")
        print(df.nlargest(5, "total_revenue").to_string(index=False))
    print("=" * 60 + "\n")

    return str(filepath)
