"""Extract data from the source database."""

import sqlite3
import logging
from pathlib import Path
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)


def create_sample_database(db_path: str) -> None:
    """Create a sample sales database if it does not exist."""
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if path.exists():
        logger.info("Sample database already exists at %s", db_path)
        return

    logger.info("Creating sample database at %s", db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE sales (
            id INTEGER PRIMARY KEY,
            sale_date TEXT NOT NULL,
            product TEXT NOT NULL,
            region TEXT NOT NULL,
            amount REAL NOT NULL,
            quantity INTEGER NOT NULL
        )
    """)

    # Insert realistic sample data
    sample_data = [
        ("2025-01-05", "Laptop", "West", 1299.99, 2),
        ("2025-01-12", "Mouse", "East", 29.99, 15),
        ("2025-01-18", "Keyboard", "West", 79.99, 8),
        ("2025-01-25", "Monitor", "South", 349.99, 4),
        ("2025-02-03", "Laptop", "East", 1199.99, 1),
        ("2025-02-10", "Headphones", "North", 149.99, 12),
        ("2025-02-14", "Mouse", "West", 29.99, 20),
        ("2025-02-20", "Laptop", "South", 1399.99, 3),
        ("2025-03-01", "Monitor", "East", 399.99, 5),
        ("2025-03-08", "Keyboard", "North", 89.99, 6),
        ("2025-03-15", "Headphones", "West", 129.99, 9),
        ("2025-03-22", "Laptop", "East", 1249.99, 2),
        ("2025-04-02", "Mouse", "South", 24.99, 25),
        ("2025-04-09", "Monitor", "West", 379.99, 3),
        ("2025-04-16", "Laptop", "North", 1499.99, 1),
        ("2025-04-23", "Headphones", "East", 159.99, 7),
        ("2025-05-05", "Keyboard", "South", 69.99, 10),
        ("2025-05-12", "Mouse", "West", 29.99, 18),
        ("2025-05-19", "Laptop", "East", 1299.99, 4),
        ("2025-05-26", "Monitor", "North", 429.99, 2),
        ("2025-06-03", "Headphones", "West", 139.99, 11),
        ("2025-06-10", "Laptop", "South", 1199.99, 2),
        ("2025-06-17", "Keyboard", "East", 79.99, 9),
        ("2025-06-24", "Mouse", "North", 34.99, 14),
        ("2025-07-01", "Monitor", "West", 359.99, 6),
        ("2025-07-08", "Laptop", "East", 1349.99, 3),
        ("2025-07-15", "Headphones", "South", 149.99, 8),
        ("2025-07-22", "Keyboard", "North", 99.99, 5),
        ("2025-08-05", "Mouse", "West", 29.99, 22),
        ("2025-08-12", "Laptop", "South", 1449.99, 1),
        ("2025-08-19", "Monitor", "East", 389.99, 4),
        ("2025-08-26", "Headphones", "North", 169.99, 6),
        ("2025-09-02", "Keyboard", "West", 74.99, 12),
        ("2025-09-09", "Laptop", "East", 1299.99, 2),
        ("2025-09-16", "Mouse", "South", 27.99, 19),
        ("2025-09-23", "Monitor", "North", 409.99, 3),
        ("2025-10-01", "Headphones", "West", 149.99, 10),
        ("2025-10-08", "Laptop", "East", 1399.99, 2),
        ("2025-10-15", "Keyboard", "South", 84.99, 7),
        ("2025-10-22", "Mouse", "North", 31.99, 16),
        ("2025-11-01", "Monitor", "West", 369.99, 5),
        ("2025-11-05", "Laptop", "East", 1249.99, 3),
    ]

    cursor.executemany(
        "INSERT INTO sales (sale_date, product, region, amount, quantity) VALUES (?, ?, ?, ?, ?)",
        sample_data,
    )
    conn.commit()
    conn.close()
    logger.info("Sample database created with %d rows", len(sample_data))


def extract(db_path: str, table: str) -> pd.DataFrame:
    """
    Extract all rows from the given table.

    Args:
        db_path: Path to the SQLite database file.
        table: Name of the table to extract.

    Returns:
        DataFrame containing the extracted data.
    """
    logger.info("Extracting data from table '%s' in %s", table, db_path)

    if not Path(db_path).exists():
        raise FileNotFoundError(f"Database not found: {db_path}")

    conn = sqlite3.connect(db_path)
    try:
        df = pd.read_sql_query(f"SELECT * FROM {table}", conn)
    finally:
        conn.close()

    logger.info("Extracted %d rows", len(df))
    return df
