# Python SQL Data Pipeline

A clean, production-style **Automated Reporting & Data Pipeline** built with Python and SQLite.

This project extracts data from a relational database, runs data-quality checks and transformations, loads cleaned results, and generates automated summary reports. It demonstrates solid software-engineering practices: modular design, logging, error handling, configuration, and unit tests.

## Features

- Extract data from SQLite (easily adaptable to SQL Server / MySQL / PostgreSQL)
- Data quality checks (nulls, duplicates, value ranges)
- Lightweight transformations and aggregations
- Automated report generation (CSV + console summary)
- Structured logging and graceful error handling
- Unit tests with `pytest`
- Simple configuration via YAML

## Project Structure

```
python-sql-data-pipeline/
├── README.md
├── requirements.txt
├── .gitignore
├── config.yaml
├── main.py
├── src/
│   ├── __init__.py
│   ├── extractor.py
│   ├── transformer.py
│   ├── loader.py
│   ├── reporter.py
│   └── pipeline.py
├── data/
│   └── sample.db          # generated on first run
├── reports/               # output reports land here
└── tests/
    └── test_pipeline.py
```

## Quick Start

### 1. Clone & setup

```bash
git clone https://github.com/YOUR_USERNAME/python-sql-data-pipeline.git
cd python-sql-data-pipeline

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Run the pipeline

```bash
python main.py
```

This will:
1. Create a sample SQLite database with sales data
2. Extract → Transform → Load
3. Run data-quality checks
4. Generate a report in the `reports/` folder

### 3. Run tests

```bash
pytest tests/ -v
```

## Example Output

```
2025-11-06 15:30:12 | INFO  | Starting data pipeline...
2025-11-06 15:30:12 | INFO  | Extracted 1000 rows from sales table
2025-11-06 15:30:12 | INFO  | Data quality: 0 critical issues found
2025-11-06 15:30:12 | INFO  | Transformed data → 12 monthly summary rows
2025-11-06 15:30:12 | INFO  | Report written to reports/sales_report_2025-11-06.csv
2025-11-06 15:30:12 | INFO  | Pipeline completed successfully
```

## Configuration

Edit `config.yaml` to change database path, table names, or report settings.

## Extending the Project

- Swap SQLite for SQL Server / PostgreSQL / AWS RDS by changing the connection string in `src/extractor.py`
- Add more sophisticated quality rules
- Schedule with cron or GitHub Actions
- Push metrics to Datadog / CloudWatch

## Technologies

- Python 3.9+
- SQLite (standard library)
- pandas
- PyYAML
- pytest

## License

MIT
